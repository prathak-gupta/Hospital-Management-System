package com.genpact.capstone_hms.doctors.controller;

import com.genpact.capstone_hms.doctors.model.Doctor;
import com.genpact.capstone_hms.doctors.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {

    private final DoctorService doctorService;

    @Autowired
    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    @PostMapping("/register")
    @ResponseBody
    public ResponseEntity<String> registerDoctor(@RequestBody Doctor doctor) {
        doctorService.createDoctor(doctor);
        return ResponseEntity.ok("Doctor registered successfully");
    }

    @GetMapping("/{id}")
    @ResponseBody
    public ResponseEntity<Doctor> getDoctorById(@PathVariable int id) {
        Doctor doctor = doctorService.readDoctor(id);
        if (doctor != null) {
            return ResponseEntity.ok(doctor);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/update/{id}")
    @ResponseBody
    public ResponseEntity<String> updateDoctor(@RequestBody Doctor doctor, @PathVariable int id) {
        doctor.setDoctorID(id);
        doctorService.updateDoctor(doctor);
        return ResponseEntity.ok("Doctor updated successfully");
    }

    @DeleteMapping("/delete/{id}")
    @ResponseBody
    public ResponseEntity<String> deleteDoctor(@PathVariable int id) {
        doctorService.deleteDoctor(id);
        return ResponseEntity.ok("Doctor deleted successfully");
    }

    @GetMapping("/search")
    @ResponseBody
    public ResponseEntity<List<Doctor>> searchDoctors(@RequestParam String keyword) {
        System.out.println("Received keyword: " + keyword);
        List<Doctor> doctors = doctorService.searchDoctors(keyword);
        System.out.println("Doctors found: " + doctors);
        return ResponseEntity.ok(doctors);
    }

    @GetMapping("/all")
    @ResponseBody
    public ResponseEntity<List<Doctor>> getAllDoctors() {
        List<Doctor> doctors = doctorService.getAllDoctors();
        return ResponseEntity.ok(doctors);
    }
}