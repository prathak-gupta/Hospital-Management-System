package com.genpact.capstone_hms.model;

import java.sql.Date;
import java.sql.Timestamp;

public class MedicalRecordsModel {
    private int recordID;
    private int patientID;
    private int doctorID;
    private String diagnosis;
    private String treatment;
    private Date date;
    private Timestamp registrationTime;

    // Parameterized Constructor
    public MedicalRecordsModel(int recordID, int patientID, int doctorID, String diagnosis, String treatment, Date date, Timestamp registrationTime) {
        this.recordID = recordID;
        this.patientID = patientID;
        this.doctorID = doctorID;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
        this.date = date;
        this.registrationTime = registrationTime;
    }

    // Extra Parameterized Constructor without ID and Registration Time
    public MedicalRecordsModel(int patientID, int doctorID, String diagnosis, String treatment, Date date) {
        this.patientID = patientID;
        this.doctorID = doctorID;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
        this.date = date;
    }

    // Getters and Setters
    public int getRecordID() {
        return recordID;
    }

    public void setRecordID(int recordID) {
        this.recordID = recordID;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Timestamp getRegistrationTime() {
        return registrationTime;
    }

    public void setRegistrationTime(Timestamp registrationTime) {
        this.registrationTime = registrationTime;
    }

    // toString Method
    @Override
    public String toString() {
        return "MedicalRecordsModel{" +
                "recordID=" + recordID +
                ", patientID=" + patientID +
                ", doctorID=" + doctorID +
                ", diagnosis='" + diagnosis + '\'' +
                ", treatment='" + treatment + '\'' +
                ", date=" + date +
                ", registrationTime=" + registrationTime +
                '}';
    }
}
