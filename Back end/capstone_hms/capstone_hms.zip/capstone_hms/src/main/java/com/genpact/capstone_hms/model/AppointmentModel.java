package com.genpact.capstone_hms.model;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

public class AppointmentModel {
    private int appointmentID;
    private int patientID;
    private int doctorID;
    private Date appointmentDate;
    private Time appointmentTime;
    private String reason;
    private Timestamp registrationTime;

    // Parameterized Constructor
    public AppointmentModel(int appointmentID, int patientID, int doctorID, Date appointmentDate, Time appointmentTime, String reason, Timestamp registrationTime) {
        this.appointmentID = appointmentID;
        this.patientID = patientID;
        this.doctorID = doctorID;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.reason = reason;
        this.registrationTime = registrationTime;
    }

    // Extra Parameterized Constructor without ID and Registration Time
    public AppointmentModel(int patientID, int doctorID, Date appointmentDate, Time appointmentTime, String reason) {
        this.patientID = patientID;
        this.doctorID = doctorID;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
        this.reason = reason;
    }

    // Getters and Setters
    public int getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public Time getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(Time appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Timestamp getRegistrationTime() {
        return registrationTime;
    }

    public void setRegistrationTime(Timestamp registrationTime) {
        this.registrationTime = registrationTime;
    }

    // toString Method
    @Override
    public String toString() {
        return "AppointmentModel{" +
                "appointmentID=" + appointmentID +
                ", patientID=" + patientID +
                ", doctorID=" + doctorID +
                ", appointmentDate=" + appointmentDate +
                ", appointmentTime=" + appointmentTime +
                ", reason='" + reason + '\'' +
                ", registrationTime=" + registrationTime +
                '}';
    }
}
