package com.genpact.capstone_hms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.genpact.capstone_hms.admin.model.Admin;
import com.genpact.capstone_hms.doctors.model.Doctor;

@Configuration
public class AppConfig {
	
//	@Bean
//	public Admin admin()
//	{
//		return new Admin("temp", "temp","temp","temp");
//	}
//	
//	@Bean
//	public Doctor dotor()
//	{
//		return new Doctor();
//	}

}
