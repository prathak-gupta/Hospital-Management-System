package com.genpact.capstone_hms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.genpact.capstone_hms.admin.model.Admin;

@Configuration
public class AppConfig {
	
//	@Bean
//	public AdminModel admin()
//	{
//		return new AdminModel("temp", "temp","temp","temp");
//	}

}
