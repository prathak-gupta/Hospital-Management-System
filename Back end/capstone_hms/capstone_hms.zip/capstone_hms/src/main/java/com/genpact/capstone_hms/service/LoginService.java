package com.genpact.capstone_hms.service;

import com.genpact.capstone_hms.model.Login;
import com.genpact.capstone_hms.repository.LoginRepository;

public class LoginService {
		LoginRepository loginService;

		public LoginService(LoginRepository loginService) {
			super();
			this.loginService = loginService;
		}
		
		public String authenticate(Login login)
		{
			if(loginService.ifUsernameExist(login.getUsername(), login.getDomain()).equalsIgnoreCase("true")
					&& loginService.ifPasswordExist(login.getUsername(), login.getDomain()).equalsIgnoreCase("true"))
			{
				return "true";
			}
			else
			{
				return loginService.getEmsg();
			}
		}
}
