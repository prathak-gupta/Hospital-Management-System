package com.genpact.capstone_hms.repository;

//import org.springframework.dao.DataAccessException;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
//
//import com.genpact.capstone_hms.model.LoginAuth;

// Til now no need of Repository becuz it will not be saving anything its just for Authentication..
@Repository
public class LoginAuthRepository {
   
}
